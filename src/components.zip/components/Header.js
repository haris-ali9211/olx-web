import React from 'react';
import { Navbar,Nav,Form,FormControl,Button } from 'react-bootstrap';
import Grouped from './Search';
import LogoOlx from '../images/Logotyp_OLX_.png'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSearch } from '@fortawesome/free-solid-svg-icons';


class Header extends React.Component{
    render(){
      const element = <FontAwesomeIcon icon={faSearch} />
        return(
          <Navbar bg="light" expand="lg">
           <Navbar.Brand href="#home">
      <img
        src={LogoOlx}
        width="45"
        height="25"
        className="d-inline-block align-top"
        alt="OLX logo"
        className="LogoOlx"
      />
    </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link href="#link"><div><image src={LogoOlx} alt="" width="50"/></div></Nav.Link>
              <Nav.Link href="#home"><Grouped/></Nav.Link>
              <Nav.Link href="#home"> <Form inline className="baraSearch">
              <FormControl type="text" placeholder="Search" className="mr-sm-2 search2" />  
              <Nav.Link  className="searchIcon" href="#home"><FontAwesomeIcon className="icons inline" icon={faSearch}/></Nav.Link>
            </Form> </Nav.Link> 
            </Nav>
            <Form inline className="baraSearch justify-content-md-center">
              <Button className="leftbtn1" variant="outline-success">LOGIN</Button>
              <Button className="leftbtn2" variant="outline-success">+SELL</Button>
            </Form>          
          </Navbar.Collapse>
        </Navbar>
        )
    }
}
export default Header;

